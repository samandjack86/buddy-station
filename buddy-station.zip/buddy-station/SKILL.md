---
name: buddy-station
display_name: 优秀Buddy加油站助手
display_name_en: Buddy Station Assistant
description: "查询 WorkBuddy 每日积分并生成播报（积分余额、连续登录、活跃地图、本周进度、本期活动与连续奖励分档），只读展示成长计划与派猫猫旅行状态，支持一键幂等自动签到（checkin）与派猫猫旅行全自动闭环（先领后派，需显式 --travel-auto）。读取本机登录态、接口直查 Buddy 加油站数据，Windows/macOS/Linux 跨平台。触发词：查积分、我的积分多少、积分余额、今天签到了吗、连续登录几天、帮我签到、自动签到、每日签到、每日播报、积分情况、派猫猫旅行、猫猫旅行、旅行积分、领旅行奖励、Buddy 在旅行吗、旅行到哪了、自动派猫猫。"
description_zh: "Buddy加油站助手：读取本机已登录 WorkBuddy 的登录态，接口直查 Buddy 加油站数据生成每日积分播报；只读展示成长计划与派猫猫旅行状态；支持一键幂等自动签到与派猫猫旅行全自动闭环（先领后派，需显式 --travel-auto）。以只读为主，写操作仅限签到与旅行领取/派出，不打印 token，不修改登录态，运行期零文件写入、不调用系统命令。兼容 WorkBuddy 5.6.2+ 客户端登录态格式。"
description_en: "Buddy Station Assistant reads the local WorkBuddy login state and queries the Buddy Station API to build a daily credit report (balance, streak, activity calendar, weekly progress, event, streak rewards). It shows the read-only growth plan and Buddy travel status, and supports one-click idempotent auto check-in and a fully automated travel loop (claim first, then depart; needs explicit --travel-auto). Cross-platform Windows/macOS/Linux. Read-only by default; write calls are limited to check-in and travel claim/depart; never prints the token, never writes files, never spawns processes. Compatible with the WorkBuddy 5.6.2+ login-state format."
category: automation
version: 1.1.0
author: 日积阅垒
agent_created: true
visibility: public
license: MIT-0
metadata:
  openclaw:
    emoji: "💰"
    requires:
      bins:
        - python3
      env: []
allowed-tools: Bash
---

# Buddy加油站助手（每日积分播报 + 自动签到 + 派猫猫旅行）

读取本机已登录 WorkBuddy 的登录态，用接口直查「Buddy 加油站」数据，汇总成每日播报；支持只读展示成长计划与派猫猫旅行状态、一键幂等自动签到、以及派猫猫旅行全自动闭环（先领后派）。结果以纯文本 / JSON 输出，由调用方在对话中呈现；不写磁盘、不弹窗、不调用任何外部程序。

> **安全边界（自证清白）**：只读取本人本机登录态文件，仅在内存中解析，绝不打印 / 落盘 / 外传 `accessToken`。写操作仅限三个已验证接口：`POST /v2/billing/meter/daily-checkin`（幂等）、`POST /activity/growth/buddy/travel/claim`、`POST /activity/growth/buddy/travel/depart`；绝不调用兑换 / 抽奖等其他写接口。旅行写操作**仅在显式加 `--travel-auto` 时执行**，且派出前必先查询 `daily_limit_reached`，达上限绝不发写请求。运行期间不修改、不删除任何文件，不执行任何系统命令。

---

## 一、何时使用（触发条件）

用户出现以下任意意图时调用本技能（按意图选对应命令），无需精确措辞：

- **查询 / 播报类**：查积分、我的积分多少、积分余额、今天多少分、今天记录没、连续登录几天、全勤能得多少分、还差几天到下一档、活动入口、每日播报、积分情况。
- **签到类**：帮我签到、签到、自动签到、每日签到、打卡。
- **派猫猫旅行类**：派猫猫旅行、猫猫旅行、旅行积分、领旅行奖励、Buddy 在旅行吗、旅行到哪了、自动派猫猫。

---

## 二、前置条件

1. **用户已登录 WorkBuddy 客户端**：本机存在登录态文件（定位见 `@references/api-spec.md` 第 1 节）。找不到时停止并提示「请先在 WorkBuddy 客户端登录」，不伪造数据。
2. **运行环境**：Python 3.8+ 标准库，无需第三方依赖。优先 `python3` / `python`；未安装可用 WorkBuddy 托管 Python：
   - Windows：`~/.workbuddy/binaries/python/versions/*/python.exe`
   - macOS / Linux：`~/.workbuddy/binaries/python/versions/*/python`

---

## 三、执行流程

1. **定位脚本**：技能安装目录 `<skill-dir>` 下的 `scripts/buddy_station.py`，用 Bash 工具执行。
2. **按意图选命令**（见下表）。
3. **获取输出**：脚本向 stdout 打印文字播报（或 `--json` 时打印 JSON），向 stderr 打印提示；不打印任何 token。
4. **向用户呈现**：把脚本回显的文字播报（或 JSON 摘要）直接整理成对话回复。

---

## 四、命令与参数

下表中 `<skill-dir>` 指本技能安装目录。

| 意图 | 命令 |
|---|---|
| 查询 / 每日播报（默认，只读） | `python "<skill-dir>/scripts/buddy_station.py"` |
| 自动签到（幂等） | `python "<skill-dir>/scripts/buddy_station.py" checkin` |
| 派猫猫旅行·只查看状态（默认，只读） | `python "<skill-dir>/scripts/buddy_station.py"` |
| 派猫猫旅行·全自动闭环（先领后派，写操作） | `python "<skill-dir>/scripts/buddy_station.py" --travel-auto` |
| 签到同时跑旅行闭环 | `python "<skill-dir>/scripts/buddy_station.py" checkin --travel-auto` |
| 全自动闭环 + 指定地点 | `python "<skill-dir>/scripts/buddy_station.py" --travel-auto --location 1` |
| 机器可读 JSON | `python "<skill-dir>/scripts/buddy_station.py" --json` |
| 签到并取 JSON | `python "<skill-dir>/scripts/buddy_station.py" checkin --json` |

**参数说明**

- 位置参数 `checkin`（或 `--checkin`）：进入自动签到分支（先查后签，幂等）。
- `--travel-auto`：执行派猫猫旅行全自动闭环（先领后派）。**这是唯一会触发旅行写操作的开关**；不加则旅行部分纯只读展示。
- `--location N`：指定派遣地点，`1`=咖啡馆、`2`=商场店铺、`3`=健身房、`4`=古镇客栈；缺省随机。四个地点时长与积分区间完全相同（随机 1-4 小时、5-10 积分），收益无差异。
- `--json`：输出机器可读 JSON，便于自动化读取。

**派猫猫旅行闭环逻辑（先领后派）**

1. 查询旅行状态 `state`：`idle` 空闲 / `traveling` 旅行中 / `arrived` 已到达待领取。
2. 若 `arrived` → 调用领取接口拿积分；领取后重新查询状态。
3. 若此时为 `idle` 且 `daily_limit_reached` 为假 → 派出；若已达每日上限 → 跳过并说明。
4. 若 `traveling` → 不派遣，仅展示到达倒计时。
- **不会丢积分**：到达后状态一直保持 `arrived` 等待领取，下次运行自动补领。
- **不会超发**：派出前必查 `daily_limit_reached`，达上限绝不发写请求。

---

## 五、输出处理规范

- **默认（非 `--json`）**：脚本向 stdout 打印文字播报，调用方整理后回显到对话。
- **绝不向对话输出 token**；控制台仅出现播报文本与提示。
- **`--json` 模式**：原样回传 JSON（含 `total_credits`、`streak_days`、`checkin_dates`、`week_progress`、`activity`、`streak_schedule`、`growth`、`travel`；签到模式另含 `checkin_result`）。
- **`travel` 字段要点**：`available` 标识旅行数据是否可取；`state` / `state_text` 旅行状态；`remaining_text` 到达倒计时；`reward_credit` 可领积分；`daily_limit_reached` 今日派遣是否达上限；`locations` 可选地点列表；`auto_log` 为 `--travel-auto` 的执行日志。

---

## 六、核心能力清单

| 能力 | 对应数据 / 接口 |
|---|---|
| 积分余额 | `total_credits`（状态查询接口） |
| 今日是否记录 | `today_checked_in`（完成一次对话即记录 1 天） |
| 连续登录天数 | `streak_days` |
| 当月活跃地图 | 当月已记录日期列表、累计记录天数 |
| 本周进度 | 本周 7 天记录情况 + 满勤缺口 |
| 本期活动 | 名称 / 状态 / 周期 / 剩余天数 / 全勤预估 / 领取状态 / 活动入口 |
| 连续奖励分档 | 7 / 14 / 28 天节点（积分 / 能量 / 补登卡 / 抽奖），含下一档缺口 |
| 记录催办 | 今日未记录时提醒「完成一次对话即可记录登录 1 天」 |
| 自动签到 | `POST /v2/billing/meter/daily-checkin`，幂等安全 |
| 成长计划（只读 GET） | 成长任务 / 进度 / 当前 Buddy |
| 派猫猫旅行·只读 | 旅行状态 / 地点 / 到达倒计时 / 可领积分 / 可选地点 / 能量 |
| 派猫猫旅行·全自动 | 先领后派闭环（`--travel-auto` 显式触发），受每日上限保护 |

> 成长计划与派猫猫旅行均已通过只读 GET 接口展示；仅「积分明细（流水）/ 兑换抽奖条件」两项暂不支持（见第八节）。

---

## 七、接口与实现参考

完整接口明细、登录态定位路径、字段映射、连续奖励分档表、派猫猫旅行接口族、签到幂等与错误处理，见 `@references/api-spec.md`；各模式真实输出片段见 `@references/examples.md`。摘要：

- **登录态**：`CodeBuddyExtension/Data/Public/auth/workbuddy-desktop.info`，取 `auth.accessToken` 与 `auth.domain`（如 `www.codebuddy.cn`）；认证头 `Authorization: Bearer <token>`。
- **兼容 5.6.2+**：新版客户端的登录态字段可能为加密信封，脚本内自包含解析模块自动识别「明文 / 信封」两种情况，只读解析、绝不回写、绝不外传登录态。
- **状态查询（只读）**：`POST /v2/billing/meter/checkin-activity-status`。
- **成长计划（只读 GET）**：`/v2/activity/growth/tasks`、`/profile`、`/buddy/info`；任一失败静默降级。
- **派猫猫旅行**（注意无 `/v2` 前缀）：只读 `GET /activity/growth/buddy/travel/status`、`/config`、`GET /activity/growth/energy`、`/buddy/quota`；写 `POST /activity/growth/buddy/travel/depart`（body `{"location_id": N}`）、`/claim`（body `{}`）。
- **自动签到（写，已验证）**：`POST /v2/billing/meter/daily-checkin`；当日已签返回 `code 10001 / "今天已签到"`——幂等，不重复发奖。

---

## 八、限制与安全约束

**两项暂不支持（已确认无可用只读接口，绝不编造）**

- 积分明细（流水）、兑换 / 抽奖条件：无可用只读来源，如实标注「暂不支持」。

**安全约束（硬规则）**

- 只读登录态文件，仅在内存中解析；绝不修改 / 删除 / 落盘 / 外传 `accessToken`，任何输出不含真实 token。
- 写操作**仅**允许三个已验证接口：`daily-checkin`、`travel/claim`、`travel/depart`；绝不调用兑换 / 抽奖等其他写接口。
- 旅行写操作**必须**显式加 `--travel-auto` 才执行；且派出前必查 `daily_limit_reached`，达上限跳过、不发写请求。
- 运行期间不写任何文件（不生成报告、不写日志、不落盘 token），不调用系统命令或外部程序；网络请求仅发往官方域名白名单（`*.codebuddy.cn` / `*.workbuddy.cn`），域名不符直接拒绝、不发请求。

**停止条件**

- 登录态缺失或 token 过期：停止，告知「请先登录 WorkBuddy」，不伪造。
- 接口返回非 0 / 非 200：停止并报告（旅行只读接口除外，失败静默降级不影响主结果）。
- 涉及「积分明细 / 兑换抽奖条件」的查询：如实标注「暂不支持」，绝不编造。
- 除上述三个写接口外的任何写接口调用请求：一律拒绝。

---

## 九、排错速查

| 现象 | 处理 |
|---|---|
| 未找到登录态 | 先登录 WorkBuddy 客户端 |
| 提示「未找到本地密钥」 | 5.6.2+ 客户端登录态为加密信封，需本机已存在 `~/.workbuddy/scripts/atrest.key`，或设置环境变量 `WORKBUDDY_ATREST_KEY`（本技能**只读**，不会写入该文件） |
| HTTP 404 | 域名错，应改用登录态 `auth.domain`；旅行接口另需确认路径**不带 `/v2` 前缀** |
| 签到 `code 10001` | 正常幂等返回，非失败 |
| 接口 500 / 空响应 | 活动期切换后端偶发，稍后重试 |
| 旅行区块不显示 | 旅行只读接口失败会静默降级；加 `--json` 看 `travel.available` |
| 「今日派遣：已达上限」 | 正常，服务端限制每天派遣次数，次日自动恢复 |
| 旅行中想提前召回 | 官方无召回接口，只能等到达后自动领取 |

---

## 十、版本与署名

- 当前版本：**1.1.0**（精简安全版）。聚焦积分查询 / 自动签到 / 派猫猫旅行三项核心能力，仅保留「本机登录态 + 本地密钥文件」这一条常规授权路径。
- 相对 1.0.0 的变更：移除系统通知（不再调用任何外部命令 / 脚本）、移除桌面 HTML 报告与文件写入、移除远程推送与多通道授权，运行期零文件写入。
- **署名**：日积阅垒。
